package com.example.mausam

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
